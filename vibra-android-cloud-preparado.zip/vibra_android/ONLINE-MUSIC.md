# Vibra — pesquisa de músicas online

O Vibra agora pode pesquisar músicas online pelo **YouTube Data API** e abrir o resultado no player incorporado do YouTube.

## Configuração

1. Crie uma chave de API no Google Cloud.
2. Ative **YouTube Data API v3** no projeto.
3. Configure `YOUTUBE_API_KEY` como variável de ambiente do servidor.
4. Não use o prefixo `VITE_`: a chave deve permanecer no servidor.

Sem essa variável, a busca online simplesmente fica desativada e a busca da biblioteca local continua funcionando.

## O que foi adicionado

- Busca por nome da música/artista na tela **Buscar**.
- Resultados online separados da biblioteca do Vibra.
- Filtro para vídeos embutíveis e reproduzíveis fora do YouTube.
- Reprodução pelo player oficial incorporado do YouTube.
- Ao escolher uma música online, a reprodução local é interrompida.

Esta integração não baixa, extrai ou separa o áudio dos vídeos. O conteúdo continua sendo reproduzido pelo player do YouTube.
