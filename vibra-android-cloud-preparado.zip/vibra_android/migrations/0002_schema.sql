-- Vibra music catalog, likes, playlists, and artist profiles

create table if not exists profiles (
  user_id      text primary key,
  display_name text not null,
  handle       text not null unique,
  bio          text,
  avatar_url   text,
  created_at   timestamptz not null default now()
);

create table if not exists tracks (
  id                serial primary key,
  user_id           text not null,
  title             text not null,
  artist_name       text not null,
  genre             text not null default 'Eletrônica',
  description       text,
  audio_url         text not null,
  cover_url         text,
  duration_seconds  integer,
  play_count        integer not null default 0,
  created_at        timestamptz not null default now()
);

create index if not exists tracks_user_id_idx on tracks (user_id);
create index if not exists tracks_created_at_idx on tracks (created_at desc);
create index if not exists tracks_genre_idx on tracks (genre);

create table if not exists likes (
  user_id    text not null,
  track_id   integer not null references tracks(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

create index if not exists likes_track_id_idx on likes (track_id);

create table if not exists playlists (
  id          serial primary key,
  user_id     text not null,
  title       text not null,
  description text,
  created_at  timestamptz not null default now()
);

create index if not exists playlists_user_id_idx on playlists (user_id);

create table if not exists playlist_tracks (
  playlist_id integer not null references playlists(id) on delete cascade,
  track_id    integer not null references tracks(id) on delete cascade,
  position    integer not null default 0,
  added_at    timestamptz not null default now(),
  primary key (playlist_id, track_id)
);

-- Catalog artist profile
insert into profiles (user_id, display_name, handle, bio)
values (
  'catalog',
  'Vibra Seleção',
  'vibra',
  'Faixas selecionadas para o catálogo inicial do Vibra.'
)
on conflict (user_id) do nothing;

-- Seed catalog tracks (instrumental SoundHelix recordings)
insert into tracks (user_id, title, artist_name, genre, description, audio_url, duration_seconds)
select * from (values
  ('catalog', 'Mar Aberto',        'Costa Norte',   'Indie',         'Ondas longas e guitarra molhada ao entardecer.',                         'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',  372),
  ('catalog', 'Luz de Neon',       'Vértice',       'Eletrônica',    'Sintetizadores quentes para a avenida à meia-noite.',                    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',  384),
  ('catalog', 'Café da Rua',       'Banda Leme',    'MPB',           'Violão, prosa e a cidade acordando devagar.',                            'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',  351),
  ('catalog', 'Depois da Chuva',   'Aurora Fria',   'Lo-fi',         'Gotas no parapeito e um piano encostado.',                               'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',  398),
  ('catalog', 'Linha do Trem',     'Os Trilhos',    'Rock',          'Distorção aberta na curva da ferrovia.',                                 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',  329),
  ('catalog', 'Coração Analógico', 'Nara Vale',     'R&B',           'Baixo redondo e voz imaginária no corredor.',                            'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',  410),
  ('catalog', 'Fim de Tarde',      'Solstício',     'Jazz',          'Saxofone atravessando a varanda às 18h.',                                'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',  365),
  ('catalog', 'Selva de Pedra',    'Alto Mar',      'Hip Hop',       'Batida seca, concreto e eco de prédio.',                                'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',  341),
  ('catalog', 'Vento Sul',         'Ilha Clara',    'Indie',         'Brisa salgada e acordes abertos.',                                       'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',  388),
  ('catalog', 'Quarto Escuro',     'Eco Zero',      'Experimental',  'Texturas granulares, quase silêncio.',                                   'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3', 356),
  ('catalog', 'Estrada 101',       'Campo Livre',   'Sertanejo',     'Viola e asfalto quente no interior.',                                    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3', 333),
  ('catalog', 'Pulso',             'Máquina Doce',  'Pop',           'Refrão brilhante feito para janela aberta.',                             'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3', 347),
  ('catalog', 'Névoa',             'Lunar',         'Eletrônica',    'Pads frios sobre uma linha de baixo paciente.',                          'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3', 401),
  ('catalog', 'Janela Amarela',    'Casa 12',       'MPB',           'Cozinha acesa, rádio antigo, alguém cantarolando.',                      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3', 319),
  ('catalog', 'Pista Molhada',     'Deriva',        'Rock',          'Delay longo depois da última luz do show.',                              'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3', 376),
  ('catalog', 'Cartão Postal',     'Horizonte',     'Lo-fi',         'Fita cassete, mar distante, verão lembrado.',                            'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3', 362)
) as v(user_id, title, artist_name, genre, description, audio_url, duration_seconds)
where not exists (select 1 from tracks limit 1);

insert into playlists (user_id, title, description)
select * from (values
  ('catalog', 'Foco Profundo',       'Instrumentais longos para estudar, escrever, construir.'),
  ('catalog', 'Noite na Cidade',     'Neon, asfalto molhado e o volume um pouco mais alto.'),
  ('catalog', 'Brasil Imaginário',   'Uma costa, um interior e uma sala com o rádio ligado.')
) as v(user_id, title, description)
where not exists (select 1 from playlists limit 1);

insert into playlist_tracks (playlist_id, track_id, position)
select p.id, t.id, x.position
from (values
  ('Foco Profundo',     'Depois da Chuva', 1),
  ('Foco Profundo',     'Névoa',           2),
  ('Foco Profundo',     'Quarto Escuro',   3),
  ('Foco Profundo',     'Cartão Postal',   4),
  ('Foco Profundo',     'Fim de Tarde',    5),
  ('Noite na Cidade',   'Luz de Neon',     1),
  ('Noite na Cidade',   'Selva de Pedra',  2),
  ('Noite na Cidade',   'Pista Molhada',   3),
  ('Noite na Cidade',   'Pulso',           4),
  ('Noite na Cidade',   'Coração Analógico', 5),
  ('Brasil Imaginário', 'Mar Aberto',      1),
  ('Brasil Imaginário', 'Café da Rua',     2),
  ('Brasil Imaginário', 'Estrada 101',     3),
  ('Brasil Imaginário', 'Janela Amarela',  4),
  ('Brasil Imaginário', 'Vento Sul',       5)
) as x(playlist_title, track_title, position)
join playlists p on p.title = x.playlist_title
join tracks t on t.title = x.track_title
on conflict do nothing;
