# Vibra — Android / APK

Este projeto foi preparado para ser empacotado como aplicativo Android usando Capacitor 8.

## O que foi preparado

- `capacitor.config.ts` com o ID `com.vibra.music` e nome `Vibra`.
- Dependências do Capacitor adicionadas ao `package.json`.
- Scripts para adicionar, sincronizar, abrir e executar o projeto Android.

## Para gerar o APK

No computador com Node.js e Android Studio/SDK instalados:

```bash
npm install
npm run build:dev
npm run android:add
npx cap sync android
npx cap open android
```

No Android Studio:

**Build → Generate App Bundles or APKs → Generate APKs**

O APK será criado na pasta `android/app/build/outputs/apk/`.

## Importante sobre o Vibra atual

O Vibra usa recursos de servidor (autenticação, banco de dados e pesquisa online). Um APK empacotado não transforma automaticamente esses recursos de servidor em código local. Para o app completo funcionar no celular, a API/servidor precisa continuar hospedada e acessível pelo aplicativo.

A pesquisa online também precisa da `YOUTUBE_API_KEY` configurada no servidor, conforme `ONLINE-MUSIC.md`.
