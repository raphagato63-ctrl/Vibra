import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import {
  Heart,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import { CoverArt } from "@/components/music/cover-art";
import { useLikedIds, useToggleLike } from "@/lib/music/hooks";
import { recordPlay } from "@/lib/music/server";
import { loadVolume, usePlayer } from "@/lib/player-store";
import { cn, formatTime } from "@/lib/utils";

export function PlayerBar() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const recorded = useRef<number | null>(null);
  const track = usePlayer((s) => s.track);
  const externalTrack = usePlayer((s) => s.externalTrack);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const progress = usePlayer((s) => s.progress);
  const duration = usePlayer((s) => s.duration);
  const volume = usePlayer((s) => s.volume);
  const muted = usePlayer((s) => s.muted);
  const shuffle = usePlayer((s) => s.shuffle);
  const repeat = usePlayer((s) => s.repeat);
  const toggle = usePlayer((s) => s.toggle);
  const closeExternal = usePlayer((s) => s.closeExternal);
  const next = usePlayer((s) => s.next);
  const prev = usePlayer((s) => s.prev);
  const seek = usePlayer((s) => s.seek);
  const setProgress = usePlayer((s) => s.setProgress);
  const setVolume = usePlayer((s) => s.setVolume);
  const toggleMute = usePlayer((s) => s.toggleMute);
  const toggleShuffle = usePlayer((s) => s.toggleShuffle);
  const cycleRepeat = usePlayer((s) => s.cycleRepeat);
  const seekTick = usePlayer((s) => s.seekTick);
  const { liked } = useLikedIds();
  const likeMut = useToggleLike();

  useEffect(() => {
    usePlayer.getState().setVolume(loadVolume());
  }, []);

  useEffect(() => {
    const el = audioRef.current;
    if (!el || seekTick === 0) return;
    el.currentTime = usePlayer.getState().progress;
  }, [seekTick]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el || !track) return;
    const nextSrc = track.audioUrl;
    if (el.getAttribute("data-src") !== nextSrc) {
      el.setAttribute("data-src", nextSrc);
      el.src = nextSrc;
      el.currentTime = 0;
      recorded.current = null;
    }
    el.volume = muted ? 0 : volume;
    if (isPlaying) {
      void el.play().catch(() => {
        usePlayer.getState().pause();
      });
    } else {
      el.pause();
    }
  }, [track, isPlaying, volume, muted]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    const onTime = () => setProgress(el.currentTime, el.duration || 0);
    const onEnded = () => usePlayer.getState().next();
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("ended", onEnded);
    el.addEventListener("loadedmetadata", onTime);
    return () => {
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("loadedmetadata", onTime);
    };
  }, [setProgress]);

  useEffect(() => {
    if (!track || !isPlaying) return;
    if (recorded.current === track.id) return;
    recorded.current = track.id;
    void recordPlay({ data: { id: track.id } });
  }, [track, isPlaying]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) {
        return;
      }
      if (e.code === "Space") {
        e.preventDefault();
        usePlayer.getState().toggle();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const seekPct = duration > 0 ? (progress / duration) * 100 : 0;
  const isLiked = track ? liked.has(track.id) : false;

  if (externalTrack) {
    return (
      <div className="border-t border-border bg-background p-3 md:p-4">
        <div className="mx-auto flex max-w-5xl flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{externalTrack.title}</p>
              <p className="truncate text-xs text-muted-foreground">{externalTrack.artistName} · YouTube</p>
            </div>
            <button type="button" onClick={closeExternal} className="rounded-full px-3 py-1.5 text-xs text-muted-foreground hover:bg-foreground/6 hover:text-foreground">
              Fechar
            </button>
          </div>
          <div className="mx-auto aspect-video w-full max-w-2xl overflow-hidden rounded-xl bg-black">
            <iframe
              key={externalTrack.videoId}
              className="h-full w-full"
              src={`https://www.youtube.com/embed/${encodeURIComponent(externalTrack.videoId)}?autoplay=1&rel=0`}
              title={externalTrack.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="border-t border-border bg-background px-3 py-2 md:px-4 md:py-3">
      <audio ref={audioRef} preload="metadata" />
      <div className="grid grid-cols-[1fr_auto] items-center gap-3 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="flex min-w-0 items-center gap-3">
          {track ? (
            <>
              <Link to="/track/$id" params={{ id: String(track.id) }} className="size-12 shrink-0 md:size-14">
                <CoverArt
                  seed={`${track.id}-${track.title}`}
                  title={track.title}
                  src={track.coverUrl}
                  rounded="sm"
                />
              </Link>
              <div className="min-w-0">
                <Link
                  to="/track/$id"
                  params={{ id: String(track.id) }}
                  className="block truncate text-sm font-medium"
                >
                  {track.title}
                </Link>
                <p className="truncate text-xs text-muted-foreground">{track.artistName}</p>
              </div>
              <button
                type="button"
                aria-label={isLiked ? "Descurtir" : "Curtir"}
                onClick={() => likeMut.mutate(track.id)}
                className="hidden size-10 place-items-center text-muted-foreground hover:text-foreground sm:grid"
              >
                <Heart className={cn("size-4", isLiked && "fill-primary text-primary")} />
              </button>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Escolha uma faixa para começar</p>
          )}
        </div>

        <div className="flex flex-col items-center gap-1.5">
          <div className="flex items-center gap-1 md:gap-2">
            <button
              type="button"
              aria-label="Aleatório"
              onClick={toggleShuffle}
              className={cn(
                "hidden size-9 place-items-center rounded-full md:grid",
                shuffle ? "text-primary" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <Shuffle className="size-4" />
            </button>
            <button
              type="button"
              aria-label="Anterior"
              onClick={prev}
              disabled={!track}
              className="grid size-10 place-items-center text-foreground disabled:opacity-40"
            >
              <SkipBack className="size-5 fill-current" />
            </button>
            <button
              type="button"
              aria-label={isPlaying ? "Pausar" : "Tocar"}
              onClick={toggle}
              disabled={!track}
              className="grid size-11 place-items-center rounded-full bg-foreground text-background disabled:opacity-40"
            >
              {isPlaying ? (
                <Pause className="size-5 fill-current" />
              ) : (
                <Play className="size-5 fill-current ml-0.5" />
              )}
            </button>
            <button
              type="button"
              aria-label="Próxima"
              onClick={next}
              disabled={!track}
              className="grid size-10 place-items-center text-foreground disabled:opacity-40"
            >
              <SkipForward className="size-5 fill-current" />
            </button>
            <button
              type="button"
              aria-label="Repetir"
              onClick={cycleRepeat}
              className={cn(
                "relative hidden size-9 place-items-center rounded-full md:grid",
                repeat === "off" ? "text-muted-foreground hover:text-foreground" : "text-primary",
              )}
            >
              {repeat === "one" ? <Repeat1 className="size-4" /> : <Repeat className="size-4" />}
            </button>
          </div>
          <div className="hidden w-full max-w-xl items-center gap-2 md:flex">
            <span className="w-10 text-right text-xs tabular-nums text-muted-foreground">
              {formatTime(progress)}
            </span>
            <input
              type="range"
              min={0}
              max={duration || 0}
              step={0.1}
              value={progress}
              disabled={!track}
              onChange={(e) => {
                const v = Number(e.target.value);
                seek(v);
                const el = audioRef.current;
                if (el) el.currentTime = v;
              }}
              className="seek-range"
              style={{ ["--seek" as string]: `${seekPct}%` }}
              aria-label="Progresso"
            />
            <span className="w-10 text-xs tabular-nums text-muted-foreground">
              {formatTime(duration)}
            </span>
          </div>
        </div>

        <div className="hidden items-center justify-end gap-2 md:flex">
          <button
            type="button"
            aria-label={muted ? "Ativar som" : "Silenciar"}
            onClick={toggleMute}
            className="grid size-9 place-items-center text-muted-foreground hover:text-foreground"
          >
            {muted || volume === 0 ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={muted ? 0 : volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="seek-range w-24"
            style={{ ["--seek" as string]: `${(muted ? 0 : volume) * 100}%` }}
            aria-label="Volume"
          />
        </div>
      </div>
    </div>
  );
}
