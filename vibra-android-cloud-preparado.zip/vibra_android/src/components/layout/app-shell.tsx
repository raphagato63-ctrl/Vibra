import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useEffect } from "react";
import { AccountMenu } from "@/components/auth/account-menu";
import { MobileNav } from "@/components/layout/mobile-nav";
import { PlayerBar } from "@/components/layout/player-bar";
import { Sidebar } from "@/components/layout/sidebar";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ensureProfile } from "@/lib/music/server";

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user } = useCurrentUserState();

  useEffect(() => {
    if (!user || user.isDevFallback) return;
    void ensureProfile({
      data: {
        displayName: user.displayName ?? user.primaryEmail ?? "Artista",
        avatarUrl: user.profileImageUrl,
      },
    }).catch(() => {
      /* profile is best-effort */
    });
  }, [user]);

  if (pathname === "/login") {
    return <Outlet />;
  }

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-background">
      <div className="flex min-h-0 flex-1 overflow-hidden">
        <Sidebar />
        <div className="flex min-h-0 min-w-0 flex-1 flex-col p-2 pl-0 max-lg:p-0">
          <header className="flex shrink-0 items-center gap-3 rounded-t-xl bg-card px-4 py-3 max-lg:rounded-none">
            <Link
              to="/search"
              className="flex h-11 min-w-0 max-w-md flex-1 items-center gap-3 rounded-full bg-elevated px-4 text-sm text-muted-foreground transition-colors duration-150 hover:bg-muted hover:text-foreground"
            >
              <Search className="size-4 shrink-0" />
              <span className="truncate">O que você quer ouvir?</span>
            </Link>
            <div className="ml-auto">
              <AccountMenu />
            </div>
          </header>
          <main className="min-h-0 flex-1 overflow-y-auto rounded-b-xl bg-card max-lg:rounded-none">
            <Outlet />
          </main>
        </div>
      </div>
      <PlayerBar />
      <MobileNav />
    </div>
  );
}
