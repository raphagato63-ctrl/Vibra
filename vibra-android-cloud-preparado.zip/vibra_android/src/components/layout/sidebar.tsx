import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Library, Plus, Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { listPlaylists } from "@/lib/music/server";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useMyPlaylists } from "@/lib/music/hooks";
import { VibraMark } from "@/components/brand/vibra-mark";

const NAV = [
  { to: "/", label: "Início", icon: Home },
  { to: "/search", label: "Buscar", icon: Search },
  { to: "/library", label: "Biblioteca", icon: Library },
] as const;

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user } = useCurrentUserState();
  const catalog = useQuery({
    queryKey: ["playlists", "catalog"],
    queryFn: () => listPlaylists({ data: { userId: "catalog" } }),
  });
  const mine = useMyPlaylists();

  return (
    <aside className="hidden h-full w-[260px] shrink-0 flex-col gap-2 p-2 lg:flex">
      <div className="rounded-xl bg-card p-4">
        <Link to="/" className="flex items-center gap-2.5">
          <VibraMark className="size-8" />
          <span className="font-display text-xl font-semibold tracking-tight">Vibra</span>
        </Link>
        <nav className="mt-5 flex flex-col gap-1">
          {NAV.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
                  active
                    ? "bg-elevated text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="flex min-h-0 flex-1 flex-col rounded-xl bg-card p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-muted-foreground">Playlists</p>
          {user && (
            <Link
              to="/library"
              search={{ new: "1" }}
              className="grid size-9 place-items-center rounded-full text-muted-foreground hover:bg-elevated hover:text-foreground"
              aria-label="Nova playlist"
            >
              <Plus className="size-4" />
            </Link>
          )}
        </div>
        <div className="mt-3 flex-1 space-y-1 overflow-y-auto pr-1">
          {(catalog.data ?? []).map((p) => (
            <Link
              key={p.id}
              to="/playlist/$id"
              params={{ id: String(p.id) }}
              className={cn(
                "block truncate rounded-md px-2 py-2 text-sm transition-colors duration-150",
                pathname === `/playlist/${p.id}`
                  ? "bg-elevated text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {p.title}
            </Link>
          ))}
          {(mine.data ?? []).length > 0 && (
            <p className="pt-3 pb-1 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Suas
            </p>
          )}
          {(mine.data ?? []).map((p) => (
            <Link
              key={p.id}
              to="/playlist/$id"
              params={{ id: String(p.id) }}
              className={cn(
                "block truncate rounded-md px-2 py-2 text-sm transition-colors duration-150",
                pathname === `/playlist/${p.id}`
                  ? "bg-elevated text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {p.title}
            </Link>
          ))}
        </div>
        <Link
          to="/upload"
          className="mt-3 flex h-11 items-center justify-center gap-2 rounded-full bg-foreground text-sm font-semibold text-background transition-transform duration-150 active:scale-[0.96]"
        >
          <Plus className="size-4" />
          Publicar faixa
        </Link>
      </div>
    </aside>
  );
}
