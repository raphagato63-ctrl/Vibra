import { cn } from "@/lib/utils";

export function VibraMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-primary", className)}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="9" fill="currentColor" />
      <path
        d="M7 18.5c2.2-6 3.4-9 4.4-9 1.4 0 1.6 8 3.6 8s2.3-11 4.6-11c2 0 2.6 12 5.4 12"
        fill="none"
        stroke="#04210d"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
