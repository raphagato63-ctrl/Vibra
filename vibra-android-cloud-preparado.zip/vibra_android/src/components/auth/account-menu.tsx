import { useState, useSyncExternalStore } from "react";
import { Link } from "@tanstack/react-router";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";

const subscribeToNothing = () => () => {};
const noGateSessionOnServer = () => false;

export function AccountMenu() {
  const { user, isPending } = useCurrentUserState();
  const [signingOut, setSigningOut] = useState(false);
  const gateSession = useSyncExternalStore(
    subscribeToNothing,
    hasGateSessionMarker,
    noGateSessionOnServer,
  );

  if (isPending) {
    return <div className="size-10 animate-pulse rounded-full bg-foreground/10" />;
  }

  if (!user) {
    return (
      <Button asChild size="sm">
        <Link to="/login">Entrar</Link>
      </Button>
    );
  }

  const label = user.displayName ?? user.primaryEmail ?? "Conta";
  const showSignOut = authEnabled && !gateSession;

  return (
    <div className="flex items-center gap-2">
      <Link
        to="/artist/$userId"
        params={{ userId: user.id }}
        className="flex items-center gap-2 rounded-full bg-elevated py-1 pr-3 pl-1 hover:bg-muted"
      >
        {user.profileImageUrl ? (
          <img
            src={user.profileImageUrl}
            alt=""
            className="size-8 rounded-full object-cover"
          />
        ) : (
          <span className="grid size-8 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
            {label.charAt(0).toUpperCase()}
          </span>
        )}
        <span className="hidden max-w-28 truncate text-sm font-medium sm:inline">
          {label}
        </span>
      </Link>
      {showSignOut && (
        <button
          type="button"
          disabled={signingOut}
          onClick={() => {
            setSigningOut(true);
            void signOut().catch(() => setSigningOut(false));
          }}
          className="hidden h-10 rounded-full px-3 text-sm text-muted-foreground hover:text-foreground disabled:cursor-wait md:inline"
        >
          {signingOut ? "Saindo…" : "Sair"}
        </button>
      )}
    </div>
  );
}
