import { Link } from "@tanstack/react-router";
import { Pause, Play } from "lucide-react";
import { CoverArt } from "@/components/music/cover-art";
import { usePlayer } from "@/lib/player-store";
import type { Track } from "@/lib/music/types";
import { cn } from "@/lib/utils";

export function TrackCard({
  track,
  queue,
}: {
  track: Track;
  queue: Track[];
}) {
  const current = usePlayer((s) => s.track);
  const playing = usePlayer((s) => s.isPlaying);
  const play = usePlayer((s) => s.play);
  const toggle = usePlayer((s) => s.toggle);
  const isCurrent = current?.id === track.id;
  const isPlayingHere = isCurrent && playing;

  return (
    <article className="group relative rounded-xl bg-transparent p-3 transition-colors duration-150 hover:bg-elevated">
      <div className="relative">
        <Link to="/track/$id" params={{ id: String(track.id) }} className="block">
          <CoverArt
            seed={`${track.id}-${track.title}`}
            title={track.title}
            src={track.coverUrl}
            rounded="md"
            className="shadow-[var(--shadow-play)]"
          />
        </Link>
        <button
          type="button"
          aria-label={isPlayingHere ? `Pausar ${track.title}` : `Tocar ${track.title}`}
          onClick={() => {
            if (isCurrent) toggle();
            else play(track, queue);
          }}
          className={cn(
            "absolute right-2 bottom-2 grid size-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-play)] transition-[opacity,transform] duration-150 ease-out",
            "opacity-100 translate-y-0 lg:opacity-0 lg:translate-y-2 lg:group-hover:opacity-100 lg:group-hover:translate-y-0",
            isPlayingHere && "lg:opacity-100 lg:translate-y-0",
          )}
        >
          {isPlayingHere ? (
            <Pause className="size-5 fill-current" />
          ) : (
            <Play className="size-5 fill-current ml-0.5" />
          )}
        </button>
      </div>
      <Link to="/track/$id" params={{ id: String(track.id) }} className="mt-3 block">
        <h3 className="truncate text-sm font-semibold tracking-tight">
          {isPlayingHere ? (
            <span className="inline-flex items-center gap-1.5 text-primary">
              <span className="inline-flex h-3 items-end gap-0.5" aria-hidden>
                <span className="eq-bar h-3" />
                <span className="eq-bar h-3" />
                <span className="eq-bar h-3" />
              </span>
              {track.title}
            </span>
          ) : (
            track.title
          )}
        </h3>
        <p className="mt-0.5 truncate text-sm text-muted-foreground">{track.artistName}</p>
      </Link>
    </article>
  );
}
