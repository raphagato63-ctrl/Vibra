import { Link } from "@tanstack/react-router";
import { Heart, Pause, Play } from "lucide-react";
import { CoverArt } from "@/components/music/cover-art";
import { useLikedIds, useToggleLike } from "@/lib/music/hooks";
import { usePlayer } from "@/lib/player-store";
import type { Track } from "@/lib/music/types";
import { cn, formatCount, formatTime } from "@/lib/utils";

export function TrackRow({
  track,
  queue,
  index,
  showAlbum = true,
}: {
  track: Track;
  queue: Track[];
  index: number;
  showAlbum?: boolean;
}) {
  const current = usePlayer((s) => s.track);
  const playing = usePlayer((s) => s.isPlaying);
  const play = usePlayer((s) => s.play);
  const toggle = usePlayer((s) => s.toggle);
  const { liked } = useLikedIds();
  const likeMut = useToggleLike();
  const isCurrent = current?.id === track.id;
  const isPlayingHere = isCurrent && playing;
  const isLiked = liked.has(track.id);

  return (
    <div
      className={cn(
        "group grid items-center gap-3 rounded-md px-3 py-2 transition-colors duration-150 hover:bg-foreground/6",
        showAlbum
          ? "grid-cols-[2rem_minmax(0,1fr)_auto] md:grid-cols-[2rem_minmax(0,1.6fr)_minmax(0,1fr)_4.5rem_2.5rem]"
          : "grid-cols-[2rem_minmax(0,1fr)_auto]",
      )}
    >
      <button
        type="button"
        aria-label={isPlayingHere ? "Pausar" : "Tocar"}
        onClick={() => {
          if (isCurrent) toggle();
          else play(track, queue);
        }}
        className="relative grid size-8 place-items-center text-sm text-muted-foreground"
      >
        <span className={cn("tabular-nums group-hover:hidden", isCurrent && "hidden")}>
          {index + 1}
        </span>
        <span
          className={cn(
            "hidden group-hover:grid place-items-center text-foreground",
            isCurrent && "grid",
          )}
        >
          {isPlayingHere ? (
            <span className="inline-flex h-3 items-end gap-0.5" aria-hidden>
              <span className="eq-bar h-3" />
              <span className="eq-bar h-3" />
              <span className="eq-bar h-3" />
            </span>
          ) : isCurrent ? (
            <Pause className="size-4 fill-current text-primary" />
          ) : (
            <Play className="size-4 fill-current ml-px" />
          )}
        </span>
      </button>

      <div className="flex min-w-0 items-center gap-3">
        {showAlbum && (
          <Link to="/track/$id" params={{ id: String(track.id) }} className="size-10 shrink-0">
            <CoverArt
              seed={`${track.id}-${track.title}`}
              title={track.title}
              src={track.coverUrl}
              rounded="sm"
            />
          </Link>
        )}
        <div className="min-w-0">
          <Link
            to="/track/$id"
            params={{ id: String(track.id) }}
            className={cn(
              "block truncate text-sm font-medium",
              isCurrent && "text-primary",
            )}
          >
            {track.title}
          </Link>
          <p className="truncate text-xs text-muted-foreground">{track.artistName}</p>
        </div>
      </div>

      <span className="hidden truncate text-sm text-muted-foreground md:block">
        {track.genre}
      </span>
      <span className="hidden text-right text-sm tabular-nums text-muted-foreground md:block">
        {track.durationSeconds ? formatTime(track.durationSeconds) : formatCount(track.playCount)}
      </span>
      <button
        type="button"
        aria-label={isLiked ? "Descurtir" : "Curtir"}
        onClick={() => likeMut.mutate(track.id)}
        className="grid size-10 place-items-center text-muted-foreground hover:text-foreground"
      >
        <Heart
          className={cn(
            "size-4",
            isLiked && "fill-primary text-primary",
          )}
        />
      </button>
    </div>
  );
}
