import { Link } from "@tanstack/react-router";
import { CoverArt } from "@/components/music/cover-art";
import type { Playlist, Track } from "@/lib/music/types";

export function PlaylistCard({
  playlist,
  coverTrack,
}: {
  playlist: Playlist;
  coverTrack?: Track | null;
}) {
  const seed = coverTrack
    ? `${coverTrack.id}-${coverTrack.title}`
    : `pl-${playlist.id}`;
  return (
    <Link
      to="/playlist/$id"
      params={{ id: String(playlist.id) }}
      className="group rounded-xl p-3 transition-colors duration-150 hover:bg-elevated"
    >
      <CoverArt
        seed={seed}
        title={playlist.title}
        src={coverTrack?.coverUrl}
        rounded="md"
        className="shadow-[var(--shadow-play)]"
      />
      <h3 className="mt-3 truncate text-sm font-semibold tracking-tight">{playlist.title}</h3>
      <p className="mt-0.5 line-clamp-2 text-sm text-muted-foreground">
        {playlist.description || `${playlist.trackCount} faixas`}
      </p>
    </Link>
  );
}
