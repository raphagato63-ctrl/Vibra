import { useState } from "react";
import { cn } from "@/lib/utils";

const PALETTES = [
  ["#14532d", "#1ed760", "#052e16"],
  ["#27272a", "#f4f4f5", "#09090b"],
  ["#1e3a5f", "#93c5fd", "#0b1220"],
  ["#3f2e1f", "#e7c9a5", "#1c140e"],
  ["#1f2937", "#6ee7b7", "#0b1320"],
  ["#111827", "#fda4af", "#1f0a10"],
  ["#0f172a", "#67e8f9", "#082f36"],
  ["#1c1917", "#fdba74", "#1c1008"],
] as const;

function hashSeed(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i += 1) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function CoverArt({
  seed,
  title,
  src,
  className,
  rounded = "md",
}: {
  seed: string;
  title: string;
  src?: string | null;
  className?: string;
  rounded?: "md" | "lg" | "sm" | "full";
}) {
  const [broken, setBroken] = useState(false);
  const round =
    rounded === "full"
      ? "rounded-full"
      : rounded === "lg"
        ? "rounded-lg"
        : rounded === "sm"
          ? "rounded-sm"
          : "rounded-md";

  if (src && !broken) {
    return (
      <img
        src={src}
        alt=""
        className={cn("aspect-square size-full object-cover", round, className)}
        onError={() => setBroken(true)}
      />
    );
  }

  const h = hashSeed(seed);
  const palette = PALETTES[h % PALETTES.length];
  const style = h % 4;
  const letter = (title.trim()[0] ?? "V").toUpperCase();

  return (
    <div
      className={cn(
        "relative aspect-square size-full overflow-hidden",
        round,
        className,
      )}
      aria-hidden="true"
    >
      <svg viewBox="0 0 100 100" className="size-full" preserveAspectRatio="xMidYMid slice">
        <rect width="100" height="100" fill={palette[2]} />
        {style === 0 && (
          <>
            <circle cx="72" cy="28" r="38" fill={palette[0]} />
            <circle cx="18" cy="78" r="30" fill={palette[1]} opacity="0.85" />
            <rect x="40" y="40" width="50" height="8" fill={palette[1]} opacity="0.5" />
          </>
        )}
        {style === 1 && (
          <>
            <polygon points="0,100 100,0 100,100" fill={palette[0]} />
            <rect x="12" y="12" width="28" height="76" fill={palette[1]} opacity="0.7" />
            <circle cx="70" cy="70" r="22" fill={palette[1]} />
          </>
        )}
        {style === 2 && (
          <>
            <rect x="-10" y="18" width="120" height="18" fill={palette[0]} transform="rotate(-12 50 50)" />
            <rect x="-10" y="48" width="120" height="14" fill={palette[1]} transform="rotate(-12 50 50)" opacity="0.85" />
            <rect x="-10" y="72" width="120" height="8" fill={palette[0]} transform="rotate(-12 50 50)" />
          </>
        )}
        {style === 3 && (
          <>
            <circle cx="50" cy="50" r="34" fill="none" stroke={palette[1]} strokeWidth="10" />
            <circle cx="50" cy="50" r="16" fill={palette[0]} />
            <rect x="8" y="8" width="18" height="18" fill={palette[1]} />
          </>
        )}
      </svg>
      <span className="pointer-events-none absolute inset-0 grid place-items-center font-display text-[42%] font-semibold tracking-tight text-foreground/90 mix-blend-soft-light">
        {letter}
      </span>
    </div>
  );
}
