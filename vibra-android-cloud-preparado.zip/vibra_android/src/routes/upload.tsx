import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { GENRES } from "@/lib/music/types";
import { publishTrack } from "@/lib/music/server";
import { isUnauthorized } from "@/lib/utils";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/upload")({ component: UploadPage });

const SAMPLE =
  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";

function UploadPage() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const play = usePlayer((s) => s.play);
  const [pending, setPending] = useState(false);
  const [genre, setGenre] = useState<(typeof GENRES)[number]>("Indie");

  if (isPending) return <div className="h-full animate-pulse bg-elevated/40" />;
  if (!user) return <RedirectToSignIn />;

  const artistDefault = user.displayName ?? "Artista";

  return (
    <div className="mx-auto max-w-xl space-y-8 px-4 py-8 pb-20">
      <header>
        <p className="text-sm text-muted-foreground">Estúdio</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Publicar faixa
        </h1>
        <p className="mt-2 text-muted-foreground">
          Cole o link direto do arquivo de áudio (MP3, WAV ou OGG). A faixa entra no
          catálogo na hora para qualquer pessoa ouvir.
        </p>
      </header>

      <form
        className="space-y-5"
        onSubmit={async (e) => {
          e.preventDefault();
          const form = e.currentTarget;
          const fd = new FormData(form);
          setPending(true);
          try {
            const track = await publishTrack({
              data: {
                title: String(fd.get("title") ?? ""),
                artistName: String(fd.get("artistName") ?? ""),
                genre,
                description: String(fd.get("description") ?? "") || null,
                audioUrl: String(fd.get("audioUrl") ?? ""),
                coverUrl: String(fd.get("coverUrl") ?? "") || null,
              },
            });
            void qc.invalidateQueries({ queryKey: ["tracks"] });
            toast.success("Faixa no ar");
            play(track, [track]);
            void navigate({ to: "/track/$id", params: { id: String(track.id) } });
          } catch (err) {
            if (isUnauthorized(err)) {
              toast.message("Entre para publicar");
              void navigate({ to: "/login" });
            } else {
              toast.error(err instanceof Error ? err.message : "Não foi possível publicar");
            }
          } finally {
            setPending(false);
          }
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="title">Título</Label>
          <Input id="title" name="title" required maxLength={120} placeholder="Nome da faixa" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="artistName">Artista</Label>
          <Input
            id="artistName"
            name="artistName"
            required
            maxLength={80}
            defaultValue={artistDefault}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="genre">Gênero</Label>
          <select
            id="genre"
            value={genre}
            onChange={(e) => setGenre(e.target.value as (typeof GENRES)[number])}
            className="flex h-11 w-full rounded-md bg-elevated px-3 text-sm shadow-[var(--shadow-border)]"
          >
            {GENRES.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="audioUrl">Link do áudio</Label>
          <Input
            id="audioUrl"
            name="audioUrl"
            required
            type="url"
            placeholder="https://…/sua-faixa.mp3"
          />
          <button
            type="button"
            className="text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
            onClick={() => {
              const el = document.getElementById("audioUrl") as HTMLInputElement | null;
              if (el) el.value = SAMPLE;
            }}
          >
            Usar um áudio de exemplo
          </button>
        </div>
        <div className="space-y-2">
          <Label htmlFor="coverUrl">Capa (opcional)</Label>
          <Input
            id="coverUrl"
            name="coverUrl"
            type="url"
            placeholder="https://…/capa.jpg"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="description">Sobre a faixa</Label>
          <Textarea
            id="description"
            name="description"
            maxLength={500}
            placeholder="Onde foi gravada, o clima, o que você quer que a pessoa sinta."
          />
        </div>
        <Button type="submit" disabled={pending} className="w-full">
          {pending ? "Publicando…" : "Publicar"}
        </Button>
      </form>
    </div>
  );
}
