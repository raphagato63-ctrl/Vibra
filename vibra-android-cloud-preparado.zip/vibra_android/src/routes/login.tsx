import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { VibraMark } from "@/components/brand/vibra-mark";
import { CoverArt } from "@/components/music/cover-art";

export const Route = createFileRoute("/login")({ component: Login });

const MOSAIC = [
  "Mar Aberto",
  "Luz de Neon",
  "Café da Rua",
  "Pulso",
  "Vento Sul",
  "Névoa",
  "Estrada 101",
  "Janela Amarela",
  "Pista Molhada",
];

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-5" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.5 12.3c0-.85-.07-1.45-.23-2.08H12v3.78h6.55c-.13 1.08-.84 2.7-2.42 3.79l-.02.14 3.51 2.72.24.02c2.24-2.07 3.54-5.12 3.54-8.37z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.2 0 5.89-1.06 7.85-2.88l-3.74-2.9c-1 .7-2.34 1.19-4.11 1.19-3.13 0-5.79-2.05-6.74-4.89l-.14.01-3.66 2.83-.05.13C3.4 21.53 7.4 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.26 14.52A7.2 7.2 0 0 1 4.86 12c0-.88.16-1.73.44-2.52l-.08-.14-3.7-2.87-.12.06A11.97 11.97 0 0 0 0 12c0 1.93.46 3.75 1.28 5.37l3.98-2.85z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c2.21 0 3.7.96 4.55 1.76l3.32-3.24C17.88 1.19 15.2 0 12 0 7.4 0 3.4 2.47 1.4 6.13l3.98 2.85C6.21 6.8 8.87 4.75 12 4.75z"
      />
    </svg>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-5 fill-current" aria-hidden="true">
      <path d="M18.9 1.5h3.67l-8.02 9.16L24 22.5h-7.41l-5.8-7.58-6.64 7.58H.46l8.58-9.8L0 1.5h7.6l5.24 6.93L18.9 1.5Zm-1.29 18.9h2.03L6.48 3.48H4.3l13.31 16.92Z" />
    </svg>
  );
}

function Login() {
  const { user, isPending } = useCurrentUserState();
  if (!isPending && user) return <Navigate to="/" />;

  return (
    <main className="relative grid min-h-dvh overflow-hidden bg-background lg:grid-cols-[1.1fr_0.9fr]">
      <div className="relative hidden items-center justify-center lg:flex">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgb(30_215_96/0.12),transparent_42%)]" />
        <div className="grid w-[min(520px,70%)] grid-cols-3 gap-3 rotate-[-8deg]">
          {MOSAIC.map((title, i) => (
            <div key={title} className="aspect-square overflow-hidden rounded-lg shadow-[var(--shadow-play)]">
              <CoverArt seed={`login-${i}-${title}`} title={title} />
            </div>
          ))}
        </div>
      </div>

      <div className="relative flex flex-col items-center justify-center px-6 py-12">
        <Link to="/" className="mb-10 flex items-center gap-2.5">
          <VibraMark className="size-10" />
          <span className="font-display text-3xl font-semibold tracking-tight">Vibra</span>
        </Link>
        <div className="w-full max-w-sm">
          <h1 className="font-display text-3xl font-semibold tracking-tight">
            Entre para publicar
          </h1>
          <p className="mt-2 text-muted-foreground">
            Ouça o catálogo agora. Para soltar sua faixa, entre com Google.
          </p>

          <div className="mt-8 flex flex-col gap-3">
            {authEnabled ? (
              GROK_PROVIDERS.map((p) => {
                const isGoogle = p.idp === "google";
                return (
                  <button
                    key={p.providerId}
                    type="button"
                    onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                    className={
                      isGoogle
                        ? "flex h-12 items-center justify-center gap-3 rounded-full bg-foreground px-4 text-sm font-semibold text-background transition-transform duration-150 active:scale-[0.96]"
                        : "flex h-12 items-center justify-center gap-3 rounded-full bg-elevated px-4 text-sm font-semibold text-foreground shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]"
                    }
                  >
                    {isGoogle ? <GoogleIcon /> : <XIcon />}
                    Continuar com {p.label}
                  </button>
                );
              })
            ) : (
              <p className="text-sm text-muted-foreground">O login está desativado.</p>
            )}
          </div>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            <Link to="/" className="underline-offset-4 hover:text-foreground hover:underline">
              Continuar ouvindo sem conta
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
