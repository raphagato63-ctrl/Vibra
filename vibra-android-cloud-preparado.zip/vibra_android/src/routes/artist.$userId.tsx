import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { CoverArt } from "@/components/music/cover-art";
import { TrackRow } from "@/components/music/track-row";
import { Button } from "@/components/ui/button";
import { getProfile, listTracks } from "@/lib/music/server";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/artist/$userId")({ component: ArtistPage });

function ArtistPage() {
  const { userId } = Route.useParams();
  const profileQ = useQuery({
    queryKey: ["profile", userId],
    queryFn: () => getProfile({ data: { userId } }),
  });
  const tracksQ = useQuery({
    queryKey: ["tracks", "artist", userId],
    queryFn: () => listTracks({ data: { userId, limit: 100 } }),
  });
  const play = usePlayer((s) => s.play);

  const tracks = tracksQ.data ?? [];
  const profile = profileQ.data;
  const name = profile?.displayName ?? tracks[0]?.artistName ?? "Artista";

  return (
    <div className="pb-16">
      <div className="flex flex-col gap-6 bg-[linear-gradient(180deg,rgb(30_215_96/0.14),transparent_70%)] px-4 py-10 md:flex-row md:items-end md:px-8">
        <div className="size-36 overflow-hidden rounded-full shadow-[var(--shadow-play)] md:size-48">
          {profile?.avatarUrl ? (
            <img src={profile.avatarUrl} alt="" className="size-full object-cover" />
          ) : (
            <CoverArt seed={userId} title={name} rounded="full" />
          )}
        </div>
        <div>
          <p className="text-sm font-medium">Artista</p>
          <h1 className="font-display mt-1 text-4xl font-semibold tracking-tight md:text-6xl">
            {name}
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {profile?.handle ? `@${profile.handle} · ` : ""}
            {tracks.length} {tracks.length === 1 ? "faixa" : "faixas"}
          </p>
          {profile?.bio && <p className="mt-2 max-w-xl text-sm text-muted-foreground">{profile.bio}</p>}
        </div>
      </div>

      <div className="px-4 py-6 md:px-8">
        {tracks.length > 0 && (
          <Button
            size="lg"
            className="size-14 p-0"
            onClick={() => play(tracks[0], tracks)}
            aria-label="Tocar tudo"
          >
            <Play className="size-6 fill-current ml-0.5" />
          </Button>
        )}
      </div>

      <div className="px-2 md:px-5">
        {tracks.map((track, i) => (
          <TrackRow key={track.id} track={track} queue={tracks} index={i} />
        ))}
        {tracks.length === 0 && !tracksQ.isLoading && (
          <p className="px-4 text-muted-foreground">Este artista ainda não publicou faixas.</p>
        )}
      </div>
    </div>
  );
}
