import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search as SearchIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { z } from "zod";
import { CardGrid, Section } from "@/components/music/section";
import { TrackCard } from "@/components/music/track-card";
import { TrackRow } from "@/components/music/track-row";
import { CoverArt } from "@/components/music/cover-art";
import { Play } from "lucide-react";
import { Input } from "@/components/ui/input";
import { GENRES } from "@/lib/music/types";
import { listTracks, searchYouTube } from "@/lib/music/server";
import { cn } from "@/lib/utils";
import { usePlayer } from "@/lib/player-store";

const searchSchema = z.object({
  q: z.string().optional(),
  genre: z.string().optional(),
  artist: z.string().optional(),
});

export const Route = createFileRoute("/search")({
  validateSearch: (s) => searchSchema.parse(s),
  component: SearchPage,
});

function SearchPage() {
  const initial = Route.useSearch();
  const [q, setQ] = useState(initial.q ?? initial.artist ?? "");
  const [genre, setGenre] = useState(initial.genre ?? "");

  const tracksQ = useQuery({
    queryKey: ["tracks", "search", q, genre, initial.artist],
    queryFn: () =>
      listTracks({
        data: {
          q: q || undefined,
          genre: genre || undefined,
          artist: initial.artist || undefined,
          limit: 80,
        },
      }),
  });

  const tracks = tracksQ.data ?? [];
  const onlineQ = useQuery({
    queryKey: ["youtube-search", q],
    queryFn: () => searchYouTube({ data: { q, limit: 8 } }),
    enabled: q.trim().length >= 2,
  });
  const onlineTracks = onlineQ.data?.tracks ?? [];
  const empty = !tracksQ.isLoading && tracks.length === 0;
  const browsing = !q && !genre && !initial.artist;

  const chips = useMemo(() => ["", ...GENRES], []);

  return (
    <div className="space-y-8 px-4 py-6 pb-16 md:px-8">
      <header className="space-y-4">
        <h1 className="font-display text-3xl font-semibold tracking-tight">Buscar</h1>
        <div className="relative max-w-xl">
          <SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="O que você quer ouvir?"
            className="h-12 rounded-full bg-elevated pl-11"
            aria-label="Buscar músicas"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {chips.map((g) => {
            const label = g || "Tudo";
            const active = genre === g;
            return (
              <button
                key={label}
                type="button"
                onClick={() => setGenre(g)}
                className={cn(
                  "h-9 rounded-full px-4 text-sm font-medium transition-colors duration-150",
                  active
                    ? "bg-foreground text-background"
                    : "bg-elevated text-muted-foreground hover:text-foreground",
                )}
              >
                {label}
              </button>
            );
          })}
        </div>
      </header>

      {q.trim().length >= 2 && onlineTracks.length > 0 && (
        <Section title="Resultados online">
          <div className="grid gap-2">
            {onlineTracks.map((track) => (
              <button
                key={track.id}
                type="button"
                onClick={() => usePlayer.getState().playExternal(track)}
                className="flex items-center gap-3 rounded-xl p-2 text-left transition-colors hover:bg-foreground/6"
              >
                <CoverArt seed={track.videoId} title={track.title} src={track.coverUrl} rounded="sm" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{track.title}</span>
                  <span className="block truncate text-xs text-muted-foreground">{track.artistName} · YouTube</span>
                </span>
                <span className="grid size-9 shrink-0 place-items-center rounded-full bg-foreground text-background">
                  <Play className="size-4 fill-current" />
                </span>
              </button>
            ))}
          </div>
        </Section>
      )}

      {empty ? (
        <p className="text-muted-foreground">Nada encontrado na sua biblioteca. Tente outro termo ou veja os resultados online.</p>
      ) : browsing ? (
        <Section title="Navegar">
          <CardGrid>
            {tracks.map((track) => (
              <TrackCard key={track.id} track={track} queue={tracks} />
            ))}
          </CardGrid>
        </Section>
      ) : (
        <div className="rounded-xl bg-elevated/40 py-1">
          {tracks.map((track, i) => (
            <TrackRow key={track.id} track={track} queue={tracks} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}
