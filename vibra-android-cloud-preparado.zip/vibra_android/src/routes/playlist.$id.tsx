import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { CoverArt } from "@/components/music/cover-art";
import { TrackRow } from "@/components/music/track-row";
import { Button } from "@/components/ui/button";
import { getPlaylist } from "@/lib/music/server";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/playlist/$id")({ component: PlaylistPage });

function PlaylistPage() {
  const { id } = Route.useParams();
  const playlistId = Number(id);
  const q = useQuery({
    queryKey: ["playlist", playlistId],
    queryFn: () => getPlaylist({ data: { id: playlistId } }),
    enabled: Number.isFinite(playlistId),
  });
  const play = usePlayer((s) => s.play);

  if (q.isLoading) return <div className="h-full animate-pulse bg-elevated/30" />;
  if (!q.data) {
    return (
      <div className="px-6 py-16 text-center">
        <h1 className="font-display text-2xl font-semibold">Playlist não encontrada</h1>
      </div>
    );
  }

  const { playlist, tracks } = q.data;
  const cover = tracks[0];

  return (
    <div className="pb-16">
      <div className="flex flex-col gap-6 bg-[linear-gradient(180deg,rgb(244_244_245/0.08),transparent_70%)] px-4 py-8 md:flex-row md:items-end md:px-8">
        <div className="size-44 shrink-0 shadow-[var(--shadow-play)] md:size-56">
          <CoverArt
            seed={cover ? `${cover.id}-${cover.title}` : `pl-${playlist.id}`}
            title={playlist.title}
            src={cover?.coverUrl}
            rounded="md"
          />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium">Playlist</p>
          <h1 className="font-display mt-1 text-4xl font-semibold tracking-tight md:text-6xl">
            {playlist.title}
          </h1>
          {playlist.description && (
            <p className="mt-3 max-w-xl text-sm text-muted-foreground">{playlist.description}</p>
          )}
          <p className="mt-2 text-sm text-muted-foreground">
            {playlist.trackCount} {playlist.trackCount === 1 ? "faixa" : "faixas"}
          </p>
        </div>
      </div>

      <div className="px-4 py-6 md:px-8">
        {tracks.length > 0 && (
          <Button
            size="lg"
            className="size-14 p-0"
            onClick={() => play(tracks[0], tracks)}
            aria-label="Tocar playlist"
          >
            <Play className="size-6 fill-current ml-0.5" />
          </Button>
        )}
      </div>

      <div className="px-2 md:px-5">
        {tracks.map((track, i) => (
          <TrackRow key={track.id} track={track} queue={tracks} index={i} />
        ))}
      </div>
    </div>
  );
}
