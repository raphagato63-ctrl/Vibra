import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart, Pause, Play, Plus } from "lucide-react";
import { useState } from "react";
import { CoverArt } from "@/components/music/cover-art";
import { TrackRow } from "@/components/music/track-row";
import { Button } from "@/components/ui/button";
import { useAddToPlaylist, useLikedIds, useMyPlaylists, useToggleLike } from "@/lib/music/hooks";
import { deleteTrack, getTrack, listTracks } from "@/lib/music/server";
import { usePlayer } from "@/lib/player-store";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatCount, formatTime } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/track/$id")({ component: TrackPage });

function TrackPage() {
  const { id } = Route.useParams();
  const trackId = Number(id);
  const { user } = useCurrentUserState();
  const qc = useQueryClient();
  const trackQ = useQuery({
    queryKey: ["track", trackId],
    queryFn: () => getTrack({ data: { id: trackId } }),
    enabled: Number.isFinite(trackId),
  });
  const moreQ = useQuery({
    queryKey: ["tracks", "home"],
    queryFn: () => listTracks({ data: { limit: 48 } }),
  });
  const current = usePlayer((s) => s.track);
  const playing = usePlayer((s) => s.isPlaying);
  const play = usePlayer((s) => s.play);
  const toggle = usePlayer((s) => s.toggle);
  const { liked } = useLikedIds();
  const likeMut = useToggleLike();
  const mine = useMyPlaylists();
  const addPl = useAddToPlaylist();
  const [menu, setMenu] = useState(false);

  const track = trackQ.data;
  if (trackQ.isLoading) {
    return <div className="h-full animate-pulse bg-elevated/30" />;
  }
  if (!track) {
    return (
      <div className="px-6 py-16 text-center">
        <h1 className="font-display text-2xl font-semibold">Faixa não encontrada</h1>
        <Link to="/" className="mt-4 inline-block text-sm underline underline-offset-4">
          Voltar ao início
        </Link>
      </div>
    );
  }

  const queue = moreQ.data ?? [track];
  const isCurrent = current?.id === track.id;
  const isPlayingHere = isCurrent && playing;
  const isLiked = liked.has(track.id);
  const more = queue.filter((t) => t.id !== track.id).slice(0, 8);
  const canDelete = user && user.id === track.userId;

  return (
    <div className="pb-16">
      <div className="flex flex-col gap-6 bg-[linear-gradient(180deg,rgb(30_215_96/0.16),transparent_70%)] px-4 py-8 md:flex-row md:items-end md:px-8">
        <div className="size-44 shrink-0 shadow-[var(--shadow-play)] md:size-56">
          <CoverArt
            seed={`${track.id}-${track.title}`}
            title={track.title}
            src={track.coverUrl}
            rounded="md"
          />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium">Faixa</p>
          <h1 className="font-display mt-1 text-4xl font-semibold tracking-tight md:text-6xl">
            {track.title}
          </h1>
          <p className="mt-3 text-sm text-foreground/90">
            {track.userId !== "catalog" ? (
              <Link
                to="/artist/$userId"
                params={{ userId: track.userId }}
                className="font-semibold hover:underline"
              >
                {track.artistName}
              </Link>
            ) : (
              <span className="font-semibold">{track.artistName}</span>
            )}
            <span className="text-muted-foreground">
              {" · "}
              {track.genre}
              {" · "}
              {formatCount(track.playCount)} plays
              {track.durationSeconds ? ` · ${formatTime(track.durationSeconds)}` : ""}
            </span>
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 px-4 py-6 md:px-8">
        <Button
          size="lg"
          onClick={() => {
            if (isCurrent) toggle();
            else play(track, queue);
          }}
          className="size-14 p-0"
          aria-label={isPlayingHere ? "Pausar" : "Tocar"}
        >
          {isPlayingHere ? (
            <Pause className="size-6 fill-current" />
          ) : (
            <Play className="size-6 fill-current ml-0.5" />
          )}
        </Button>
        <button
          type="button"
          aria-label={isLiked ? "Descurtir" : "Curtir"}
          onClick={() => likeMut.mutate(track.id)}
          className="grid size-12 place-items-center text-muted-foreground hover:text-foreground"
        >
          <Heart className={isLiked ? "size-7 fill-primary text-primary" : "size-7"} />
        </button>
        {user && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenu((v) => !v)}
              className="grid size-12 place-items-center text-muted-foreground hover:text-foreground"
              aria-label="Adicionar à playlist"
            >
              <Plus className="size-6" />
            </button>
            {menu && (
              <div className="absolute top-12 left-0 z-20 w-56 rounded-xl bg-elevated p-2 shadow-[var(--shadow-play)]">
                {(mine.data ?? []).length === 0 ? (
                  <p className="px-2 py-2 text-sm text-muted-foreground">
                    Crie uma playlist na biblioteca.
                  </p>
                ) : (
                  (mine.data ?? []).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      className="block w-full rounded-md px-3 py-2 text-left text-sm hover:bg-foreground/8"
                      onClick={() => {
                        addPl.mutate({ playlistId: p.id, trackId: track.id });
                        setMenu(false);
                      }}
                    >
                      {p.title}
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        )}
        {canDelete && (
          <Button
            variant="ghost"
            onClick={async () => {
              await deleteTrack({ data: { id: track.id } });
              void qc.invalidateQueries({ queryKey: ["tracks"] });
              toast.success("Faixa removida");
            }}
          >
            Remover
          </Button>
        )}
      </div>

      {track.description && (
        <p className="max-w-2xl px-4 text-muted-foreground md:px-8">{track.description}</p>
      )}

      {more.length > 0 && (
        <div className="mt-8 px-2 md:px-5">
          <h2 className="px-3 font-display text-xl font-semibold">Recomendadas</h2>
          <div className="mt-2">
            {more.map((t, i) => (
              <TrackRow key={t.id} track={t} queue={queue} index={i} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
