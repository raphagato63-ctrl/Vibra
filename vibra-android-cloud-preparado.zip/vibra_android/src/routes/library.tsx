import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlaylistCard } from "@/components/music/playlist-card";
import { CardGrid, Section } from "@/components/music/section";
import { TrackRow } from "@/components/music/track-row";
import { useCreatePlaylist, useMyPlaylists } from "@/lib/music/hooks";
import { listLikedTracks, listTracks } from "@/lib/music/server";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  new: z.string().optional(),
  tab: z.enum(["liked", "uploads", "playlists"]).optional(),
});

export const Route = createFileRoute("/library")({
  validateSearch: (s) => searchSchema.parse(s),
  component: LibraryPage,
});

function LibraryPage() {
  const { user, isPending } = useCurrentUserState();
  const search = Route.useSearch();
  const [tab, setTab] = useState<"liked" | "uploads" | "playlists">(
    search.tab ?? "liked",
  );
  const [open, setOpen] = useState(search.new === "1");
  const [title, setTitle] = useState("");
  const createPl = useCreatePlaylist();
  const mine = useMyPlaylists();

  const likedQ = useQuery({
    queryKey: ["liked-tracks"],
    queryFn: () => listLikedTracks(),
    enabled: Boolean(user) && !isPending,
  });
  const uploadsQ = useQuery({
    queryKey: ["tracks", "mine", user?.id],
    queryFn: () => listTracks({ data: { userId: user!.id, limit: 100 } }),
    enabled: Boolean(user) && !isPending,
  });

  useEffect(() => {
    if (search.new === "1") setOpen(true);
  }, [search.new]);

  if (isPending) {
    return <div className="h-full animate-pulse bg-elevated/40" />;
  }
  if (!user) return <RedirectToSignIn />;

  const liked = likedQ.data ?? [];
  const uploads = uploadsQ.data ?? [];

  return (
    <div className="space-y-8 px-4 py-6 pb-16 md:px-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Biblioteca</p>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Sua música</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setOpen(true)}>
            Nova playlist
          </Button>
          <Button asChild>
            <Link to="/upload">Publicar faixa</Link>
          </Button>
        </div>
      </header>

      <div className="flex gap-2">
        {(
          [
            ["liked", "Curtidas"],
            ["uploads", "Suas faixas"],
            ["playlists", "Playlists"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={cn(
              "h-9 rounded-full px-4 text-sm font-medium",
              tab === id
                ? "bg-foreground text-background"
                : "bg-elevated text-muted-foreground hover:text-foreground",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {open && (
        <form
          className="flex max-w-md flex-col gap-3 rounded-xl bg-elevated p-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!title.trim()) return;
            createPl.mutate(title.trim(), {
              onSuccess: () => {
                setTitle("");
                setOpen(false);
                setTab("playlists");
              },
            });
          }}
        >
          <Label htmlFor="pl-title">Nome da playlist</Label>
          <Input
            id="pl-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Ex: Noite de estúdio"
            autoFocus
          />
          <div className="flex gap-2">
            <Button type="submit" disabled={createPl.isPending}>
              Criar
            </Button>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      )}

      {tab === "liked" && (
        liked.length ? (
          <div className="rounded-xl bg-elevated/40 py-1">
            {liked.map((track, i) => (
              <TrackRow key={track.id} track={track} queue={liked} index={i} />
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">
            Ainda sem curtidas. Toque no coração para guardar uma faixa.
          </p>
        )
      )}

      {tab === "uploads" && (
        uploads.length ? (
          <div className="rounded-xl bg-elevated/40 py-1">
            {uploads.map((track, i) => (
              <TrackRow key={track.id} track={track} queue={uploads} index={i} />
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">
            Você ainda não publicou.{" "}
            <Link to="/upload" className="underline underline-offset-4">
              Envie sua primeira faixa
            </Link>
            .
          </p>
        )
      )}

      {tab === "playlists" && (
        (mine.data ?? []).length ? (
          <Section title="Suas playlists">
            <CardGrid>
              {(mine.data ?? []).map((p) => (
                <PlaylistCard key={p.id} playlist={p} />
              ))}
            </CardGrid>
          </Section>
        ) : (
          <p className="text-muted-foreground">Crie uma playlist para organizar o que você ama.</p>
        )
      )}
    </div>
  );
}
