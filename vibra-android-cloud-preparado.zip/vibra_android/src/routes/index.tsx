import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { useEffect, useState } from "react";
import { CoverArt } from "@/components/music/cover-art";
import { PlaylistCard } from "@/components/music/playlist-card";
import { CardGrid, Section } from "@/components/music/section";
import { Skeleton } from "@/components/ui/skeleton";
import { TrackCard } from "@/components/music/track-card";
import { TrackRow } from "@/components/music/track-row";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { listPlaylists, listTracks } from "@/lib/music/server";
import { usePlayer } from "@/lib/player-store";
import { greetingForHour } from "@/lib/utils";
import { GENRES } from "@/lib/music/types";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user } = useCurrentUserState();
  const [greet, setGreet] = useState("Olá");
  useEffect(() => {
    setGreet(greetingForHour(new Date().getHours()));
  }, []);
  const tracksQ = useQuery({
    queryKey: ["tracks", "home"],
    queryFn: () => listTracks({ data: { limit: 48 } }),
  });
  const playlistsQ = useQuery({
    queryKey: ["playlists", "catalog"],
    queryFn: () => listPlaylists({ data: { userId: "catalog" } }),
  });
  const play = usePlayer((s) => s.play);

  const tracks = tracksQ.data ?? [];
  const playlists = playlistsQ.data ?? [];
  const featured = tracks.slice(0, 6);
  const recent = tracks.slice(0, 8);
  const byGenre = GENRES.map((g) => ({
    genre: g,
    tracks: tracks.filter((t) => t.genre === g).slice(0, 6),
  })).filter((g) => g.tracks.length > 0);

  const name = user?.displayName?.split(" ")[0];

  return (
    <div className="space-y-10 px-4 py-6 pb-16 md:px-8">
      <header>
        <p className="text-sm font-medium text-muted-foreground">Vibra</p>
        <h1 className="font-display mt-1 text-3xl font-semibold tracking-tight md:text-4xl">
          {greet}
          {name ? `, ${name}` : ""}
        </h1>
      </header>

      {tracksQ.isLoading ? (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-md" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {featured.map((track) => (
            <button
              key={track.id}
              type="button"
              onClick={() => play(track, tracks)}
              className="group flex items-center gap-3 overflow-hidden rounded-md bg-foreground/6 text-left transition-colors duration-150 hover:bg-foreground/12"
            >
              <div className="size-16 shrink-0">
                <CoverArt
                  seed={`${track.id}-${track.title}`}
                  title={track.title}
                  src={track.coverUrl}
                  rounded="sm"
                />
              </div>
              <span className="min-w-0 flex-1 truncate pr-2 text-sm font-semibold">
                {track.title}
              </span>
              <span className="mr-3 grid size-10 place-items-center rounded-full bg-primary text-primary-foreground opacity-0 shadow-[var(--shadow-play)] transition-opacity duration-150 group-hover:opacity-100 max-md:opacity-100">
                <Play className="size-4 fill-current ml-px" />
              </span>
            </button>
          ))}
        </div>
      )}

      <Section title="Feito para você">
        {tracksQ.isLoading ? (
          <CardGrid>
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="aspect-square rounded-lg" />
            ))}
          </CardGrid>
        ) : (
          <CardGrid>
            {tracks.slice(0, 6).map((track) => (
              <TrackCard key={track.id} track={track} queue={tracks} />
            ))}
          </CardGrid>
        )}
      </Section>

      <Section
        title="Playlists da casa"
        action={
          <Link to="/search" className="text-sm font-medium text-muted-foreground hover:text-foreground">
            Ver tudo
          </Link>
        }
      >
        <CardGrid>
          {playlists.map((p) => (
            <PlaylistCard
              key={p.id}
              playlist={p}
              coverTrack={tracks.find((t) => t.id === p.coverTrackId)}
            />
          ))}
        </CardGrid>
      </Section>

      <Section title="Recém publicadas">
        <div className="rounded-xl bg-elevated/40 py-1">
          {recent.map((track, i) => (
            <TrackRow key={track.id} track={track} queue={tracks} index={i} />
          ))}
        </div>
      </Section>

      {byGenre.slice(0, 3).map((g) => (
        <Section
          key={g.genre}
          title={g.genre}
          action={
            <Link
              to="/search"
              search={{ genre: g.genre }}
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Ver tudo
            </Link>
          }
        >
          <CardGrid>
            {g.tracks.map((track) => (
              <TrackCard key={track.id} track={track} queue={g.tracks} />
            ))}
          </CardGrid>
        </Section>
      ))}
    </div>
  );
}
