import { create } from "zustand";
import type { ExternalTrack, Track } from "@/lib/music/types";

type RepeatMode = "off" | "all" | "one";

type PlayerState = {
  track: Track | null;
  externalTrack: ExternalTrack | null;
  queue: Track[];
  index: number;
  isPlaying: boolean;
  progress: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  play: (track: Track, queue?: Track[]) => void;
  playExternal: (track: ExternalTrack) => void;
  closeExternal: () => void;
  toggle: () => void;
  pause: () => void;
  next: () => void;
  prev: () => void;
  seek: (seconds: number) => void;
  setProgress: (seconds: number, duration: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  seekTick: number;
};

export function loadVolume(): number {
  if (typeof window === "undefined") return 0.85;
  try {
    const raw = window.localStorage.getItem("vibra.volume");
    const n = raw ? Number(raw) : 0.85;
    return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0.85;
  } catch {
    return 0.85;
  }
}

export const usePlayer = create<PlayerState>((set, get) => ({
  track: null,
  externalTrack: null,
  queue: [],
  index: -1,
  isPlaying: false,
  progress: 0,
  duration: 0,
  volume: 0.85,
  muted: false,
  shuffle: false,
  repeat: "off",
  seekTick: 0,

  play: (track, queue) => {
    set({ externalTrack: null });
    const nextQueue = queue && queue.length ? queue : get().queue;
    const idx = nextQueue.findIndex((t) => t.id === track.id);
    set({
      track,
      queue: nextQueue.length ? nextQueue : [track],
      index: idx >= 0 ? idx : 0,
      isPlaying: true,
      progress: 0,
    });
  },

  playExternal: (track) => set({ track: null, externalTrack: track, isPlaying: true, progress: 0, duration: 0 }),

  closeExternal: () => set({ externalTrack: null, isPlaying: false }),

  toggle: () => {
    const { track, isPlaying } = get();
    if (!track) return;
    set({ isPlaying: !isPlaying });
  },

  pause: () => set({ isPlaying: false }),

  next: () => {
    const { queue, index, shuffle, repeat, track } = get();
    if (!queue.length) return;
    if (repeat === "one" && track) {
      set({ progress: 0, isPlaying: true, seekTick: Date.now() });
      return;
    }
    let nextIndex: number;
    if (shuffle) {
      if (queue.length === 1) nextIndex = 0;
      else {
        nextIndex = Math.floor(Math.random() * queue.length);
        if (nextIndex === index) nextIndex = (index + 1) % queue.length;
      }
    } else {
      nextIndex = index + 1;
      if (nextIndex >= queue.length) {
        if (repeat === "all") nextIndex = 0;
        else {
          set({ isPlaying: false, progress: 0 });
          return;
        }
      }
    }
    set({
      index: nextIndex,
      track: queue[nextIndex],
      isPlaying: true,
      progress: 0,
    });
  },

  prev: () => {
    const { queue, index, progress } = get();
    if (!queue.length) return;
    if (progress > 3) {
      set({ progress: 0, seekTick: Date.now() });
      return;
    }
    const prevIndex = index <= 0 ? queue.length - 1 : index - 1;
    set({
      index: prevIndex,
      track: queue[prevIndex],
      isPlaying: true,
      progress: 0,
    });
  },

  seek: (seconds) => set({ progress: Math.max(0, seconds), seekTick: Date.now() }),

  setProgress: (seconds, duration) => set({ progress: seconds, duration }),

  setVolume: (volume) => {
    const v = Math.min(1, Math.max(0, volume));
    try {
      window.localStorage.setItem("vibra.volume", String(v));
    } catch {
      /* ignore */
    }
    set({ volume: v, muted: v === 0 });
  },

  toggleMute: () => set((s) => ({ muted: !s.muted })),

  toggleShuffle: () => set((s) => ({ shuffle: !s.shuffle })),

  cycleRepeat: () =>
    set((s) => ({
      repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off",
    })),
}));
