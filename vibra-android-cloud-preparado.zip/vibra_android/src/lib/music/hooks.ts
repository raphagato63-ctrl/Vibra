import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { isUnauthorized } from "@/lib/utils";
import {
  addToPlaylist,
  createPlaylist,
  getLikedTrackIds,
  listMyPlaylists,
  toggleLike,
} from "./server";

export function useLikedIds() {
  const { user, isPending } = useCurrentUserState();
  const query = useQuery({
    queryKey: ["liked-ids"],
    queryFn: () => getLikedTrackIds(),
    enabled: Boolean(user) && !isPending,
  });
  return {
    liked: new Set(query.data ?? []),
    isLoading: query.isLoading,
  };
}

export function useToggleLike() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: (id: number) => toggleLike({ data: { id } }),
    onMutate: async (id) => {
      if (!user && !isPending) {
        toast.message("Entre para curtir músicas");
        void navigate({ to: "/login" });
        throw new Error("Unauthorized");
      }
      await qc.cancelQueries({ queryKey: ["liked-ids"] });
      const prev = qc.getQueryData<number[]>(["liked-ids"]);
      qc.setQueryData<number[]>(["liked-ids"], (old = []) =>
        old.includes(id) ? old.filter((x) => x !== id) : [...old, id],
      );
      return { prev };
    },
    onError: (err, _id, ctx) => {
      if (ctx?.prev) qc.setQueryData(["liked-ids"], ctx.prev);
      if (isUnauthorized(err)) {
        toast.message("Entre para curtir músicas");
        void navigate({ to: "/login" });
      }
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: ["liked-ids"] });
      void qc.invalidateQueries({ queryKey: ["tracks"] });
      void qc.invalidateQueries({ queryKey: ["liked-tracks"] });
      void qc.invalidateQueries({ queryKey: ["track"] });
    },
  });
}

export function useMyPlaylists() {
  const { user, isPending } = useCurrentUserState();
  return useQuery({
    queryKey: ["my-playlists"],
    queryFn: () => listMyPlaylists(),
    enabled: Boolean(user) && !isPending,
  });
}

export function useCreatePlaylist() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (title: string) => createPlaylist({ data: { title } }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["my-playlists"] });
      toast.success("Playlist criada");
    },
  });
}

export function useAddToPlaylist() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { playlistId: number; trackId: number }) =>
      addToPlaylist({ data }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["my-playlists"] });
      void qc.invalidateQueries({ queryKey: ["playlist"] });
      toast.success("Adicionada à playlist");
    },
  });
}
