export const GENRES = [
  "Pop",
  "Rock",
  "Hip Hop",
  "Eletrônica",
  "MPB",
  "Sertanejo",
  "Jazz",
  "Indie",
  "R&B",
  "Lo-fi",
  "Experimental",
] as const;

export type Genre = (typeof GENRES)[number];

export type Track = {
  id: number;
  userId: string;
  title: string;
  artistName: string;
  genre: string;
  description: string | null;
  audioUrl: string;
  coverUrl: string | null;
  durationSeconds: number | null;
  playCount: number;
  likeCount: number;
  createdAt: string;
};

export type Playlist = {
  id: number;
  userId: string;
  title: string;
  description: string | null;
  createdAt: string;
  trackCount: number;
  coverTrackId: number | null;
};

export type Profile = {
  userId: string;
  displayName: string;
  handle: string;
  bio: string | null;
  avatarUrl: string | null;
  createdAt: string;
  trackCount: number;
};


export type ExternalTrack = {
  id: string;
  title: string;
  artistName: string;
  coverUrl: string | null;
  videoId: string;
  source: "youtube";
};
