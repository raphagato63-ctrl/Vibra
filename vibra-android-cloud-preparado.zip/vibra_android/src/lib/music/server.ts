import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { slugify } from "@/lib/utils";
import type { Playlist, Profile, Track } from "./types";
import { GENRES, type ExternalTrack } from "./types";
import { env } from "@/lib/env.server";

type TrackRow = {
  id: number;
  user_id: string;
  title: string;
  artist_name: string;
  genre: string;
  description: string | null;
  audio_url: string;
  cover_url: string | null;
  duration_seconds: number | null;
  play_count: number;
  like_count: number;
  created_at: string;
};

function mapTrack(row: TrackRow): Track {
  return {
    id: Number(row.id),
    userId: row.user_id,
    title: row.title,
    artistName: row.artist_name,
    genre: row.genre,
    description: row.description,
    audioUrl: row.audio_url,
    coverUrl: row.cover_url,
    durationSeconds: row.duration_seconds == null ? null : Number(row.duration_seconds),
    playCount: Number(row.play_count ?? 0),
    likeCount: Number(row.like_count ?? 0),
    createdAt: String(row.created_at),
  };
}

const TRACK_SELECT = `
  t.id, t.user_id, t.title, t.artist_name, t.genre, t.description,
  t.audio_url, t.cover_url, t.duration_seconds, t.play_count,
  coalesce(l.cnt, 0)::int as like_count,
  t.created_at::text as created_at
`;

const TRACK_FROM = `
  from tracks t
  left join (select track_id, count(*)::int as cnt from likes group by track_id) l
    on l.track_id = t.id
`;

const listInput = z.object({
  q: z.string().max(120).optional(),
  genre: z.string().max(40).optional(),
  userId: z.string().max(80).optional(),
  artist: z.string().max(80).optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

export const listTracks = createServerFn({ method: "GET" })
  .validator((data: unknown) => listInput.parse(data ?? {}))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const limit = data.limit ?? 48;
    const q = data.q?.trim();
    const like = q ? `%${q}%` : null;
    const rows = await sql.query<TrackRow>(
      `select ${TRACK_SELECT} ${TRACK_FROM}
       where ($1::text is null or t.title ilike $1 or t.artist_name ilike $1 or t.genre ilike $1)
         and ($2::text is null or t.genre = $2)
         and ($3::text is null or t.user_id = $3)
         and ($4::text is null or t.artist_name ilike $4)
       order by t.created_at desc
       limit $5`,
      [
        like,
        data.genre ?? null,
        data.userId ?? null,
        data.artist ? `%${data.artist}%` : null,
        limit,
      ],
    );
    return rows.map(mapTrack);
  });



const youtubeSearchInput = z.object({
  q: z.string().trim().min(2).max(120),
  limit: z.number().int().min(1).max(10).optional(),
});

export const searchYouTube = createServerFn({ method: "GET" })
  .validator((data: unknown) => youtubeSearchInput.parse(data))
  .handler(async ({ data }) => {
    const apiKey = env("YOUTUBE_API_KEY");
    if (!apiKey) return { configured: false, tracks: [] as ExternalTrack[] };

    const url = new URL("https://www.googleapis.com/youtube/v3/search");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("q", data.q);
    url.searchParams.set("type", "video");
    url.searchParams.set("maxResults", String(data.limit ?? 8));
    url.searchParams.set("regionCode", "BR");
    url.searchParams.set("relevanceLanguage", "pt");
    url.searchParams.set("videoEmbeddable", "true");
    url.searchParams.set("videoSyndicated", "true");
    url.searchParams.set("safeSearch", "moderate");
    url.searchParams.set("key", apiKey);

    const response = await fetch(url);
    if (!response.ok) {
      return { configured: true, tracks: [] as ExternalTrack[], error: "Não foi possível pesquisar no YouTube agora." };
    }

    const payload = (await response.json()) as {
      items?: Array<{
        id?: { videoId?: string };
        snippet?: {
          title?: string;
          channelTitle?: string;
          thumbnails?: { medium?: { url?: string }; default?: { url?: string } };
        };
      }>;
    };

    const tracks = (payload.items ?? [])
      .filter((item) => item.id?.videoId && item.snippet?.title)
      .map((item) => ({
        id: `youtube:${item.id!.videoId}`,
        title: item.snippet!.title!,
        artistName: item.snippet!.channelTitle ?? "YouTube",
        coverUrl: item.snippet!.thumbnails?.medium?.url ?? item.snippet!.thumbnails?.default?.url ?? null,
        videoId: item.id!.videoId!,
        source: "youtube" as const,
      }));

    return { configured: true, tracks };
  });

export const getTrack = createServerFn({ method: "GET" })
  .validator((data: unknown) => z.object({ id: z.number().int() }).parse(data))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql.query<TrackRow>(
      `select ${TRACK_SELECT} ${TRACK_FROM} where t.id = $1`,
      [data.id],
    );
    return rows[0] ? mapTrack(rows[0]) : null;
  });

const publishInput = z.object({
  title: z.string().trim().min(1).max(120),
  artistName: z.string().trim().min(1).max(80),
  genre: z.string().refine((g) => (GENRES as readonly string[]).includes(g), "Gênero inválido"),
  description: z.string().trim().max(500).optional().nullable(),
  audioUrl: z
    .string()
    .trim()
    .url()
    .refine((u) => /^https?:\/\//i.test(u), "Informe um link http(s)"),
  coverUrl: z.string().trim().optional().nullable(),
});

export const publishTrack = createServerFn({ method: "POST" })
  .validator((data: unknown) => publishInput.parse(data))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const cover =
      data.coverUrl && /^https?:\/\//i.test(data.coverUrl) ? data.coverUrl : null;
    const rows = await sql.query<TrackRow>(
      `insert into tracks (user_id, title, artist_name, genre, description, audio_url, cover_url)
       values ($1, $2, $3, $4, $5, $6, $7)
       returning id, user_id, title, artist_name, genre, description, audio_url, cover_url,
                 duration_seconds, play_count, 0::int as like_count, created_at::text as created_at`,
      [
        context.userId,
        data.title,
        data.artistName,
        data.genre,
        data.description || null,
        data.audioUrl,
        cover,
      ],
    );
    return mapTrack(rows[0]);
  });

export const deleteTrack = createServerFn({ method: "POST" })
  .validator((data: unknown) => z.object({ id: z.number().int() }).parse(data))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql.query(
      `delete from tracks where id = $1 and user_id = $2`,
      [data.id, context.userId],
    );
    return { ok: true };
  });

export const toggleLike = createServerFn({ method: "POST" })
  .validator((data: unknown) => z.object({ id: z.number().int() }).parse(data))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const existing = await sql.query<{ ok: number }>(
      `select 1 as ok from likes where user_id = $1 and track_id = $2`,
      [context.userId, data.id],
    );
    if (existing.length) {
      await sql.query(`delete from likes where user_id = $1 and track_id = $2`, [
        context.userId,
        data.id,
      ]);
      return { liked: false };
    }
    await sql.query(`insert into likes (user_id, track_id) values ($1, $2)`, [
      context.userId,
      data.id,
    ]);
    return { liked: true };
  });

export const getLikedTrackIds = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql.query<{ track_id: number }>(
      `select track_id from likes where user_id = $1`,
      [context.userId],
    );
    return rows.map((r) => Number(r.track_id));
  });

export const listLikedTracks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql.query<TrackRow>(
      `select ${TRACK_SELECT} ${TRACK_FROM}
       join likes lk on lk.track_id = t.id
       where lk.user_id = $1
       order by lk.created_at desc`,
      [context.userId],
    );
    return rows.map(mapTrack);
  });

export const recordPlay = createServerFn({ method: "POST" })
  .validator((data: unknown) => z.object({ id: z.number().int() }).parse(data))
  .handler(async ({ data }) => {
    const sql = await getSql();
    await sql.query(`update tracks set play_count = play_count + 1 where id = $1`, [
      data.id,
    ]);
    return { ok: true };
  });

const profileInput = z.object({
  displayName: z.string().trim().min(1).max(80),
  avatarUrl: z.string().optional().nullable(),
});

export const ensureProfile = createServerFn({ method: "POST" })
  .validator((data: unknown) => profileInput.parse(data))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const handle = `${slugify(data.displayName)}-${context.userId.slice(-4)}`;
    await sql.query(
      `insert into profiles (user_id, display_name, handle, avatar_url)
       values ($1, $2, $3, $4)
       on conflict (user_id) do update set
         display_name = excluded.display_name,
         avatar_url = coalesce(excluded.avatar_url, profiles.avatar_url)`,
      [context.userId, data.displayName, handle, data.avatarUrl || null],
    );
    return { ok: true };
  });

export const getProfile = createServerFn({ method: "GET" })
  .validator((data: unknown) => z.object({ userId: z.string() }).parse(data))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql.query<{
      user_id: string;
      display_name: string;
      handle: string;
      bio: string | null;
      avatar_url: string | null;
      created_at: string;
      track_count: number;
    }>(
      `select p.user_id, p.display_name, p.handle, p.bio, p.avatar_url,
              p.created_at::text as created_at,
              (select count(*)::int from tracks t where t.user_id = p.user_id) as track_count
       from profiles p where p.user_id = $1`,
      [data.userId],
    );
    const row = rows[0];
    if (!row) return null;
    const profile: Profile = {
      userId: row.user_id,
      displayName: row.display_name,
      handle: row.handle,
      bio: row.bio,
      avatarUrl: row.avatar_url,
      createdAt: String(row.created_at),
      trackCount: Number(row.track_count),
    };
    return profile;
  });

type PlaylistRow = {
  id: number;
  user_id: string;
  title: string;
  description: string | null;
  created_at: string;
  track_count: number;
  cover_track_id: number | null;
};

function mapPlaylist(row: PlaylistRow): Playlist {
  return {
    id: Number(row.id),
    userId: row.user_id,
    title: row.title,
    description: row.description,
    createdAt: String(row.created_at),
    trackCount: Number(row.track_count ?? 0),
    coverTrackId: row.cover_track_id == null ? null : Number(row.cover_track_id),
  };
}

const PLAYLIST_SELECT = `
  p.id, p.user_id, p.title, p.description, p.created_at::text as created_at,
  (select count(*)::int from playlist_tracks pt where pt.playlist_id = p.id) as track_count,
  (select pt.track_id from playlist_tracks pt where pt.playlist_id = p.id order by pt.position asc limit 1) as cover_track_id
`;

export const listPlaylists = createServerFn({ method: "GET" })
  .validator((data: unknown) =>
    z.object({ userId: z.string().optional() }).parse(data ?? {}),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql.query<PlaylistRow>(
      `select ${PLAYLIST_SELECT} from playlists p
       where ($1::text is null or p.user_id = $1)
       order by p.created_at desc`,
      [data.userId ?? "catalog"],
    );
    return rows.map(mapPlaylist);
  });

export const listMyPlaylists = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql.query<PlaylistRow>(
      `select ${PLAYLIST_SELECT} from playlists p
       where p.user_id = $1
       order by p.created_at desc`,
      [context.userId],
    );
    return rows.map(mapPlaylist);
  });

export const getPlaylist = createServerFn({ method: "GET" })
  .validator((data: unknown) => z.object({ id: z.number().int() }).parse(data))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql.query<PlaylistRow>(
      `select ${PLAYLIST_SELECT} from playlists p where p.id = $1`,
      [data.id],
    );
    const playlist = rows[0] ? mapPlaylist(rows[0]) : null;
    if (!playlist) return null;
    const tracks = await sql.query<TrackRow>(
      `select ${TRACK_SELECT} ${TRACK_FROM}
       join playlist_tracks pt on pt.track_id = t.id
       where pt.playlist_id = $1
       order by pt.position asc, pt.added_at asc`,
      [data.id],
    );
    return { playlist, tracks: tracks.map(mapTrack) };
  });

export const createPlaylist = createServerFn({ method: "POST" })
  .validator((data: unknown) =>
    z.object({ title: z.string().trim().min(1).max(80) }).parse(data),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql.query<PlaylistRow>(
      `insert into playlists (user_id, title)
       values ($1, $2)
       returning id, user_id, title, description, created_at::text as created_at,
                 0::int as track_count, null::int as cover_track_id`,
      [context.userId, data.title],
    );
    return mapPlaylist(rows[0]);
  });

export const addToPlaylist = createServerFn({ method: "POST" })
  .validator((data: unknown) =>
    z.object({ playlistId: z.number().int(), trackId: z.number().int() }).parse(data),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: number }>(
      `select id from playlists where id = $1 and user_id = $2`,
      [data.playlistId, context.userId],
    );
    if (!owned.length) return { ok: false };
    await sql.query(
      `insert into playlist_tracks (playlist_id, track_id, position)
       values ($1, $2, coalesce((select max(position) from playlist_tracks where playlist_id = $1), 0) + 1)
       on conflict do nothing`,
      [data.playlistId, data.trackId],
    );
    return { ok: true };
  });

export const removeFromPlaylist = createServerFn({ method: "POST" })
  .validator((data: unknown) =>
    z.object({ playlistId: z.number().int(), trackId: z.number().int() }).parse(data),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql.query(
      `delete from playlist_tracks pt
       using playlists p
       where pt.playlist_id = p.id
         and p.id = $1 and p.user_id = $2 and pt.track_id = $3`,
      [data.playlistId, context.userId, data.trackId],
    );
    return { ok: true };
  });
