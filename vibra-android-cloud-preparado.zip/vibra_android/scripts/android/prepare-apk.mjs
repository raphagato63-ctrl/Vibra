import { execSync } from 'node:child_process';

const run = (cmd) => execSync(cmd, { stdio: 'inherit', shell: true });

run('npm install');
run('npm run build:dev');
run('npx cap add android');
run('npx cap sync android');
console.log('\nVibra preparado para abrir no Android Studio.');
