import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.vibra.music',
  appName: 'Vibra',
  webDir: '.output/public',
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
  },
  server: {
    // For local Android builds, the app is bundled from webDir.
    // If you deploy Vibra and want the APK to load the hosted app,
    // set the production URL here and remove/comment this file's
    // server block as appropriate for your deployment strategy.
  },
};

export default config;
